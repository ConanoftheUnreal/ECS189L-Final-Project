curl -LJO https://github.com/polarith/AI-Formation/archive/refs/heads/master.tar.gz
tar -xf AI-Formation-master.tar.gz
cd AI-Formation-master/Assets/
cp -nr ./ ../../../../../
cd ../../
rm -rf AI-Formation-master*
